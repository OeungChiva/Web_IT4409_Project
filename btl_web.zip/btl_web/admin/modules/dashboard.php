<style>
  <?php include 'css/styleadmin.css'; ?>
</style>
<h4>Thống kê đơn hàng theo : <span id="text-date"></span></h4>
<p>
	<select class="select-date">
		<option value="7ngay">7 ngày qua</option>
		<option value="30ngay">30 ngày qua</option>
		<option value="90ngay">90 ngày qua</option>
		<option value="365ngay">365 ngày qua</option>
	</select>
</p>
<div id="chart" style="height: 250px;"></div>
