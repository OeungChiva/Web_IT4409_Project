<div class="wrapper">
  <ul class="admin_list">
    <li class="active"><a href="index.php">Thống kê</a></li>
    <li><a href="index.php?action=quanlydanhmucsanpham&query=them">Quản lý danh mục sản phẩm</a></li>
    <li><a href="index.php?action=quanlysp&query=them">Quản lý sản phẩm</a></li>
    <li><a href="index.php?action=quanlydonhang&query=lietke">Quản lý đơn hàng</a></li> 
  </ul>
</div>
<script src="active.js"></script>